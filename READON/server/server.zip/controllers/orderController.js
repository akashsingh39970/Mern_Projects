import Order from "../models/order.js";
import Product from "../models/product.js";


//place order COD : /api/order/cod
export const placeOrderCod = async (req, res) =>{
    try {
        const {userId, items, address }= req.body;
        if(!address || items.lenght === 0){
            return  res.json({success: flase, message: ' Invalid data'});
        }
        //calculate amount using items
        let amount = await items.reduce(async (acc, item) =>{
            const prodduct = await Product.findById(item.product);
            return (await acc) + prodduct.offerPrice * item.quantity;

        }, 0)

        //Add tax charge  (2%)
        amount += Math.floor(amount * 0.2);

        await Order.create({
            userId,
            items,
            amount,
            address,
            paymentType: 'COD',
        });

        return res.json({success: true, message: 'order placed'});

    } catch (error) {
        console.log(error.message);
        return res.json({success: false, message: error.message});
        
    }
}


// Get Order by USerId   : /api/order/user

export const getUserOrder = async (req, res) =>{
    try {
        const {userId} = req.body;
        const orders = await Order.find({
            userId,
            $or: [{paymentType: 'COD'},{isPaid: true}]
        }).populate('items.product address').sort({cretedAct: -1});
        res.json({success: true, orders})
    } catch (error) {
        res.json({success: false, message: error.message});
    }
}


//Get All order for selelr/admin:  /api/order/seller

export const getAllOrders = async (req, res) =>{
    try {
       
        const orders = await Order.find({
            $or: [{paymentType: 'COD'},{isPaid: true}]
        }).populate('items.product address').sort({cretedAct: -1});
        res.json({success: true, orders})
    } catch (error) {
        res.json({success: false, message: error.message});
    }
}


